
namespace BLL;

using System;
using System.Collections.Generic;
using BOL;
using DAL;
public class EmpService
{
    public static bool Register(int id, string name, string date, string wd, float hours,string status)
    {
        return DBManager.Register(id,name,date,wd,hours,status);

    }

    public static List<Employee> getAll()
    {
        return DBManager.getAll();
    }

    public static int getCount()
    {
        return DBManager.getCount();
    }
}