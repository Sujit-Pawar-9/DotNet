using System.Runtime.CompilerServices;

namespace BOL;
public class Employee{

   
    public int EmpID{get;set;}
    public String EmpName{get;set;}
    public String Date{get;set;}
    public String Work_Desc{get;set;}
    public float Hours{get;set;}
    public String Status{get;set;}
}