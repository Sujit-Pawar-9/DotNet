using System.Diagnostics;
using BOL;
using BLL;
using Microsoft.AspNetCore.Mvc;
using TSAPP.Models;

namespace TSAPP.Controllers;

public class EmployeeController : Controller
{
    private readonly ILogger<EmployeeController> _logger;

    public EmployeeController(ILogger<EmployeeController> logger)
    {
        _logger = logger;
    }

    [HttpGet]
    public IActionResult Register()
    {

        return View();
    }
    
    [HttpPost]
    public IActionResult Register(int id,string name,string date,string wd,float hours,string status)
    {
        bool flag=EmpService.Register(id,name,date,wd,hours,status);
        return View();
    }

    public IActionResult List()
    {
        List<Employee> list = new List<Employee>();
        list=EmpService.getAll();
        ViewData["list"]=list;
        return View();
    }

    public IActionResult Details(int id)
    {
        List<Employee> list = new List<Employee>();
        list=EmpService.getAll();
        Employee e=list.Find((emp)=>emp.EmpID==id);
        ViewData["emp"]=e;
        return View();
    }
    public IActionResult Privacy()
    {
        return View();
    }
    public IActionResult Count()
    {
        int n=EmpService.getCount();
        ViewData["cnt"]= n.ToString() ;
        return View();
    }
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
