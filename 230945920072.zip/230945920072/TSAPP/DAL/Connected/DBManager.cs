namespace DAL;
using BOL;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
public class DBManager
{

    public static string conString= @"server=192.168.10.150 ; port =3306; user= dac13; password = welcome; database=dac13;";
    private static int n;

    public static bool Register(int id, string name, string date, string wd, float hours,string status)
    {
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        string query="insert into Employee values(@id,@name,@date,@wd,@hours,@status)";
         try
        {
            con.Open();
            MySqlCommand cmd= new MySqlCommand(query,con);
            cmd.Parameters.AddWithValue("@id",id);
            cmd.Parameters.AddWithValue("@name",name);
              cmd.Parameters.AddWithValue("@date",date);
            cmd.Parameters.AddWithValue("@wd",wd);
            cmd.Parameters.AddWithValue("@hours",hours);
            cmd.Parameters.AddWithValue("@status",status);
          int n= cmd.ExecuteNonQuery();
          if(n>0){
            return true;
          }
    
    }
     catch(Exception ee){
            Console.WriteLine(ee.Message);
        }
        finally
        {
            con.Close();
        }
            return false;
    }

    public static List<Employee> getAll(){

        List<Employee> list = new List<Employee>();
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        string query = "select * from Employee";
        try
        {
            con.Open();
            MySqlCommand cmd= new MySqlCommand();
            cmd.Connection=con;
            cmd.CommandText=query;

            MySqlDataReader reader = cmd.ExecuteReader();
            while(reader.Read()) {
                int id = int.Parse((reader["Id"]).ToString());
                string name = reader["name"].ToString();
                string date = reader["date"].ToString();
                string wd= reader["work_desc"].ToString();
                float hours = float.Parse((reader["hours"]).ToString());
                string status = reader["status"].ToString();

            Employee e= new Employee{
                EmpID=id,
                EmpName=name,
                Date=date,
                Work_Desc=wd,
                Hours=hours,
                Status=status
            };
            list.Add(e);
            }
            
        }

        catch(Exception ee){
            Console.WriteLine(ee.Message);
        }
        finally
        {
            con.Close();
        }

        return list;
        }

    public static int getCount()
    {
       
         MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        string query = "select count(*) from employee;";
        try
        {
            con.Open();
            MySqlCommand cmd= new MySqlCommand();
            cmd.Connection=con;
            cmd.CommandText=query;

            MySqlDataReader reader = cmd.ExecuteReader();
             while(reader.Read()) {
                int n = int.Parse((reader["Id"]).ToString());
             }
             return n;

    }catch(Exception ee){
            Console.WriteLine(ee.Message);
        }
        finally
        {
            con.Close();
        }

        return n;
        }



    // public Boolean Update(Employee e){

    //     MySqlConnection con = new MySqlConnection();
    //     con.ConnectionString = conString;
    //     // string query = "update ";
    //     return true;

    // }

}
